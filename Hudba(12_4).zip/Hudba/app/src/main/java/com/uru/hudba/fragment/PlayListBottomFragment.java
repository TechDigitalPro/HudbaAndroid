package com.uru.hudba.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.andrefrsousa.superbottomsheet.SuperBottomSheetFragment;
import com.bumptech.glide.Glide;
import com.uru.hudba.R;
import com.uru.hudba.model.TrackModel;

public class PlayListBottomFragment extends SuperBottomSheetFragment implements View.OnClickListener {
    public PlayListBottomFragment(String image_url, String title, String subtitle){
        this.content_image_url = image_url;
        this.title = title;
        this.subtitle = subtitle;
    }

    private View rootView;
    private ImageView img_content, img_add, img_remove, img_filter, img_rename;
    private TextView txt_title, txt_subtitle;

    private String content_image_url, title, subtitle;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        rootView = inflater.inflate(R.layout.fragment_playlist_bottom,container,false);
        img_content = rootView.findViewById(R.id.image);
        txt_subtitle = rootView.findViewById(R.id.artist);
        txt_title = rootView.findViewById(R.id.title);


        img_add = rootView.findViewById(R.id.add);
        img_add.setOnClickListener(this);
        img_remove = rootView.findViewById(R.id.remove);
        img_remove.setOnClickListener(this);
        img_filter = rootView.findViewById(R.id.filter);
        img_filter.setOnClickListener(this);
        img_rename = rootView.findViewById(R.id.rename);
        img_rename.setOnClickListener(this);

        try {
            Glide.with(getActivity())
                    .load(content_image_url)
                    .placeholder(R.drawable.bg_round_rect)
                    .into(img_content);
            txt_title.setText(title);
            txt_subtitle.setText(subtitle);
        }catch (Exception e){
            e.printStackTrace();
        }

        return rootView;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.add:
                break;
            case R.id.remove:
                break;
            case R.id.filter:
                break;
            case R.id.rename:
                break;
        }
    }
    @Override
    public float getCornerRadius(){
        return  getActivity().getResources().getDimension(R.dimen.padding_20);
    }

    @Override
    public int getPeekHeight(){
        return 1200;
    }
    @Override
    public void onPause() {
        super.onPause();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}
