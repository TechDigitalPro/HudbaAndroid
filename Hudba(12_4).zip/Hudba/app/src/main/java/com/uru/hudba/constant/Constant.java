package com.uru.hudba.constant;

import android.content.Context;

import com.uru.hudba.model.TrackModel;

import java.io.Serializable;
import java.util.ArrayList;

public class Constant implements Serializable {
    public static int playPos = 0;
    public static ArrayList<TrackModel> arrayList_play = new ArrayList<>();

    public static Boolean isRepeat = false, isSuffle = false, isPlayed = false, isToNoti = false, isAppOpen = false, isOnline = true,
            isDownloaded = false, isBannerAd = true, isInterAd = true, isNativeAd = true, isSongDownload = false, isUpdate = false;
    public static Context context;

}
