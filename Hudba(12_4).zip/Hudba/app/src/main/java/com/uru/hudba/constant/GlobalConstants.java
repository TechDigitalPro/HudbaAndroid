package com.uru.hudba.constant;


public class GlobalConstants {

    private static final String ApiVersion = "&api_version=1";
    private static final String Client = "?client=android";
//    public static final String BaseUrl = "http://192.168.0.76/hudba/mobile/";

    public static final String BaseUrl = "http://wamusic.net/hudba/mobile/";

    public static final String CHAT_SOCKET_SERVER_URL = "http://192.168.0.76:8090/";

    public static final String SmsUrl = BaseUrl + "main/account_verification" + Client + ApiVersion;
    public static final String SmsResendEmailUrl = BaseUrl + "main/send_verification_email" + Client + ApiVersion;
    public static final String SmsResendPhoneUrl = BaseUrl + "main/send_verification_code" + Client + ApiVersion;
    public static final String SignupemailUrl = BaseUrl + "main/signup_email" + Client + ApiVersion;
    public static final String SignupphoneUrl = BaseUrl + "main/signup_phone" + Client + ApiVersion;
    public static final String LoginUrl = BaseUrl + "main/login" + Client + ApiVersion;
    public static final String ForgotUrl = BaseUrl + "main/forgot_password" + Client + ApiVersion;
    public static final String FaceBookLoginUrl = BaseUrl + "main/login_facebook" + Client + ApiVersion;
    public static final String GoogleLoginUrl = BaseUrl + "main/login_google" + Client + ApiVersion;

//    public static final String GetFeedListUrl = BaseUrl + "post/index" + Client + ApiVersion;
    public static final String GetFeedListUrl = BaseUrl + "post/search" + Client + ApiVersion;
    public static final String SearchFeedListUrl = BaseUrl + "post/search" + Client + ApiVersion;
    public static final String GetMyFriendUrl = BaseUrl + "friend/get_my_friend_list" + Client + ApiVersion;
    public static final String GetMyFollowUrl = BaseUrl + "follow/get_follower_list" + Client + ApiVersion;
    public static final String GetMyFollowingUrl = BaseUrl + "follow/get_following_list" + Client + ApiVersion;
    public static final String GetMyGallery = BaseUrl + "post/my_gallery" + Client + ApiVersion;

    public static final String UploadPhotoUrl = BaseUrl + "post/add" + Client + ApiVersion;

    public static final String AddLikeUrl = BaseUrl + "post/like" + Client + ApiVersion;
    public static final String AddFriendUrl = BaseUrl + "friend/request" + Client + ApiVersion;
    public static final String AddFollowUrl = BaseUrl + "follow/request" + Client + ApiVersion;

    public static final String AcceptFriendUrl = BaseUrl + "friend/accept" + Client + ApiVersion;
    public static final String CancelFriendUrl = BaseUrl + "friend/cancel_friend" + Client + ApiVersion;

    public static final String AcceptFollowUrl = BaseUrl + "follow/accept" + Client + ApiVersion;
    public static final String UnFollowUrl = BaseUrl + "follow/unfollow" + Client + ApiVersion;

    public static final String UpdatePostUrl = BaseUrl + "post/update" + Client + ApiVersion;
    public static final String DeletePostUrl = BaseUrl + "post/delete" + Client + ApiVersion;

    public static final String GetCountUrl = BaseUrl + "user/get_social_count" + Client + ApiVersion;
    public static final String GetUserProfileUrl = BaseUrl + "user/profile" + Client + ApiVersion;
    public static final String UpdateProfileUrl = BaseUrl + "user/update_profile" + Client + ApiVersion;
    public static final String UpdateProfileImageUrl = BaseUrl + "user/update_profile_image" + Client + ApiVersion;
    public static final String DeleteAccountUrl = BaseUrl + "user/close" + Client + ApiVersion;
    public static final String GetUserBalanceInfoUrl = BaseUrl + "user/balance_info" + Client + ApiVersion;
    public static final String SaveUserBalanceInfoUrl = BaseUrl + "user/update_balance_info" + Client + ApiVersion;
    public static final String LogoutUrl = BaseUrl + "main/logout" + Client + ApiVersion + "&memberKey=";

    public static final String GetNotificationList = BaseUrl + "notification/get_list" + Client + ApiVersion + "&memberKey=";
    public static final String DeleteNotification = BaseUrl + "notification/delete_notification" + Client + ApiVersion;
    public static final String GetUnreadNotificationCount = BaseUrl + "user/get_balance_unread_notification_count" + Client + ApiVersion + "&memberKey=";
    public static final String ReadNotification = BaseUrl + "notification/read_notification" + Client + ApiVersion;
    public static final String GetContactList = BaseUrl + "chat/contact_list" + Client + ApiVersion + "&memberKey=";
    public static final String message_lists = BaseUrl + "chat/msg_list"+ Client + ApiVersion + "&memberKey=";
    public static final String chat_img_upload = BaseUrl + "chat/upload_image"+ Client + ApiVersion + "&memberKey=";
    public static final String GetNotificationSetting = BaseUrl + "notification/get_notification_setting"+ Client + ApiVersion + "&memberKey=";
    public static final String UpdateNotificationSetting = BaseUrl + "user/update_user_setting" + Client + ApiVersion;

    public static final String RequestPayout = BaseUrl + "user/request_payout" + Client + ApiVersion;
    public static final String GetMembershipStatus = BaseUrl + "user/get_membership_status" + Client + ApiVersion + "&memberKey=";
    public static final String SetMembershipStatus = BaseUrl + "user/set_membership_status" + Client + ApiVersion + "&memberKey=";
    public static final String DONATE_URL = BaseUrl + "payment/add_payment" + Client + ApiVersion +"&memberKey=";

    public static final String HOME_LIST = BaseUrl + "main/getTotalList" + Client + ApiVersion;
    public static final String ALBUM_DETAIL_LIST = BaseUrl + "main/getPlaylistDetail" + Client + ApiVersion;
    public static final String SELECT_ALL_LIST = BaseUrl + "main/getSelectAllList" + Client + ApiVersion;
    public static final String SEARCH_VIDEOID = BaseUrl + "main/searchVideoID" + Client + ApiVersion;
    public static final String SEARCH_LIST = BaseUrl + "main/getSearchList" + Client + ApiVersion;
    public static final String SEARCH_DETAIL = BaseUrl + "main/getSearchDetail" + Client + ApiVersion;
    public static final String ADD_FAVORITE = BaseUrl + "main/add_favorite" + Client + ApiVersion;
    public static final String ADD_DOWNLOAD = BaseUrl + "main/add_download" + Client + ApiVersion;

    public static final String SAVED_LIST = BaseUrl + "library/getSavedTrackList" + Client + ApiVersion;
    public static final String MYPLAY_LIST = BaseUrl + "library/get_playlist" + Client + ApiVersion +"&memberKey=";
    public static final String CREATEPLAY_LIST = BaseUrl + "library/create_playlist" + Client + ApiVersion +"&memberKey=";
    public static final String RENAME_SONG = BaseUrl + "library/rename_song" + Client + ApiVersion +"&memberKey=";
    public static final String DELETE_SAVED_SONG = BaseUrl + "library/delete_saved_song" + Client + ApiVersion +"&memberKey=";

    public static final String ON_CONTACT_CREATED = "contact_created";
    public static final String ON_RECEIVE_MSG = "receive_msg";
    public static final String ON_READ_MSG = "read_msg";
    public static final String ON_READ_ALL_MSG = "read_all_msg";
    public static final String ON_DELETE_MSG = "msg_deleted";
    public static final String ON_ONLINE_STATUS = "online_status_changed";
    public static final String ON_BADGE_NUMBER = "unread_msg_cnt";
    public static final String ON_UPDATE_LAST_MSG = "update_last_msg";
    public static final String EMIT_CONTACT_CREATE = "create_contact";
    public static final String EMIT_SEND_MSG = "send_msg";
    public static final String EMIT_READ_MSG = "read_msg";
    public static final String EMIT_DELETE_MSG = "delete_msg";
    public static final String EMIT_READALL_MSG = "read_all_msg";

    public static final String DELIVERED = "1";

    public static final String term_link = "https://hudba.org/termsAndConditions";
    public static final String privacy_link = "https://hudba.org/privacy";
    public static final String office_link = "https://hudba.org";
    public static final String find_face_link = "https://www.facebook.com/hudbaapp-112917347291626";
    public static final String find_instagram_link = "https://www.instagram.com/@hudba.app";
    public static final String find_twitter_link = "https://mobile.twitter.com/@hudba09";
    public static final String contact_link = "https://m.me/hudbaapp-112917347291626";

    public static final int PICK_FROM_CAMERA = 101;
    public static final int PICK_FROM_FILE = 102;

    public static final String OUTPUT_DATE_FORMATE="dd/MM/yyyy hh:mm a";
    public static final String OUTPUT_DATE_FORMATE1="dd/MM/yyyy";

    public static final String stripe_key = "pk_test_51H9uOiLK3aaJdkUt4Zqt2tm4bEpO08xus5aBswa7PiWepVqyQRSljYMogPmFEIqQ0Eol6T0gAYP89gWdKMm53aDM00xRpOVAh1";

    //share preference
    public static final String PRE_MEMBER_KEY = "member_key";
    public static final String PRE_USER_ID = "user_id";
    public static final String PRE_USER_EMAIL = "user_email";
    public static final String PRE_USER_PASS = "user_password";
    public static final String PRE_USER_NAME = "user_name";
    public static final String PRE_USER_FIRSTNAME = "first_name";
    public static final String PRE_USER_LASTNAME = "last_name";
    public static final String PRE_USER_IMAGE = "user_image";

    public static final String PRE_PLAYING_MODE = "playing_mode";
    public static final String PRE_VOLUME_MODE = "volume_mode";



}
