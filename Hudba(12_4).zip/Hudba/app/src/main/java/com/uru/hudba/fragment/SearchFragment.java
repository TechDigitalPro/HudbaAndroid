package com.uru.hudba.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;
import com.google.gson.Gson;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.uru.hudba.App;
import com.uru.hudba.R;
import com.uru.hudba.activity.MainActivity;
import com.uru.hudba.adapter.AlbumAdapter;
import com.uru.hudba.adapter.SearchAdapter;
import com.uru.hudba.base.BaseFragment;
import com.uru.hudba.constant.CommonUtils;
import com.uru.hudba.constant.GlobalConstants;
import com.uru.hudba.model.AlbumModel;
import com.uru.hudba.model.SearchModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.uru.hudba.constant.GlobalConstants.PRE_MEMBER_KEY;

public class SearchFragment extends BaseFragment {
    private View rootView;
    private ImageView btn_profile;
    private RecyclerView rv_search;
    private SearchView searchTxt;

    private ArrayList<SearchModel> searchList = new ArrayList<>();
    private SearchAdapter searchAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((MainActivity) getActivity()).current_page = "search";
        rootView = inflater.inflate(R.layout.fragment_search, container, false);
        initView();
        getData();
        return rootView;
    }

    private void initView() {
        btn_profile = rootView.findViewById(R.id.btn_profile);
        btn_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity) getActivity()).onClickAccount();
            }
        });
        rv_search = rootView.findViewById(R.id.rv_search);
        rv_search.setLayoutManager(new GridLayoutManager(getContext(), 2));
        searchTxt = rootView.findViewById(R.id.search_txt);
        searchTxt.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchAdapter.searchItems(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchAdapter.searchItems(newText);
                return false;
            }
        });
        searchTxt.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        searchTxt.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                return false;
            }
        });
    }
    private void getData(){
        searchList.clear();
        String member_key = App.readSharedSetting(PRE_MEMBER_KEY, "");
        if (App.isNetworkAvailable(getContext())) {
            CommonUtils.showLoadingDialog(getActivity());
            Ion.with(getContext())
                    .load(GlobalConstants.SEARCH_LIST)
                    .setTimeout(CommonUtils.NETWORK_TIME)
                    .setBodyParameter("memberKey", member_key)
                    .asString()
                    .setCallback(new FutureCallback<String>() {
                        @Override
                        public void onCompleted(Exception e, String result) {
                            CommonUtils.hideLoadingDialog();
                            if (e == null) {
                                try {
                                    JSONObject resultObj = new JSONObject(result);
                                    if (resultObj.getString("res").equalsIgnoreCase("success")) {
                                        JSONObject api_result = resultObj.getJSONObject("api_result");
                                        JSONArray articleArray = api_result.getJSONArray("list");
                                        Gson gson = new Gson();

                                        if (articleArray.length() == 0){
                                            searchList.clear();
                                        }else {
                                            for (int i = 0; i < articleArray.length(); i++) {
                                                SearchModel topModel = gson.fromJson(articleArray.getJSONObject(i).toString(), SearchModel.class);
                                                searchList.add(topModel);
                                            }
                                            createRV(searchList);
                                        }

                                    } else {
                                        ((MainActivity)getActivity()).showErrorMessages(resultObj.getString("err_msg"));
                                    }
                                } catch (JSONException ex) {
                                    ex.printStackTrace();
                                }
                            } else {
                                ((MainActivity)getActivity()).showErrorMessages(R.string.txt_server_error);
                            }
                        }
                    });
        } else {
            ((MainActivity)getActivity()).showErrorMessages(R.string.txt_network_error);
        }
    }
    private void createRV(ArrayList<SearchModel> songModels){
        searchAdapter = new SearchAdapter(getContext(), songModels,getFragmentManager());
        searchAdapter.notifyDataSetChanged();
        rv_search.setAdapter(searchAdapter);
        searchAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = searchList.get(rv_search.getChildAdapterPosition(view)).getSearch_id();
                String title = searchList.get(rv_search.getChildAdapterPosition(view)).getTitle();
                String image = searchList.get(rv_search.getChildAdapterPosition(view)).getCover_image();

                Bundle bundle = new Bundle();
                SearchDetailFragment frag = new SearchDetailFragment();
                bundle.putString("id", id);
                bundle.putString("title", title);
                bundle.putString("image", image);
                frag.setArguments(bundle);
                pushFragment(frag, true, SearchDetailFragment.class.getName());
            }
        });
    }
}
