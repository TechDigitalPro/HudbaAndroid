package com.uru.hudba.activity.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.uru.hudba.R;
import com.uru.hudba.base.BaseActivity;

public class AuthActivity extends BaseActivity implements View.OnClickListener {

    private Button facebookButton, signupButton, loginButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        setFullScreen(this);
        initView();
    }

    private void initView() {
        facebookButton = findViewById(R.id.auth_facebook_button);
        facebookButton.setOnClickListener(this);
        signupButton = findViewById(R.id.auth_signup_button);
        signupButton.setOnClickListener(this);
        loginButton = findViewById(R.id.auth_login_button);
        loginButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.auth_facebook_button:
                facebookLogin();
                break;
            case R.id.auth_signup_button:
                gotoSignUp();
                break;
            case R.id.auth_login_button:
                gotoLogin();
                break;
        }
    }

    private void gotoLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void gotoSignUp() {
        Intent intent = new Intent(this, SignUpActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void facebookLogin() {
    }
}