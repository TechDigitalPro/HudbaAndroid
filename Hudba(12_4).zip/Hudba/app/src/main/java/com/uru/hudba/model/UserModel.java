package com.uru.hudba.model;

import com.google.gson.annotations.SerializedName;

public class UserModel {
    @SerializedName("id")
    private String id;
    @SerializedName("user_nickname")
    private String nickname;
    @SerializedName("user_name")
    private String name;
    @SerializedName("user_first_name")
    private String first_name;
    @SerializedName("user_last_name")
    private String last_name;
    @SerializedName("user_image")
    private String image;
    @SerializedName("user_email")
    private String email;
    @SerializedName("birthday")
    private String birthday;
    @SerializedName("user_phone")
    private String phone;
    @SerializedName("country_code")
    private String country_code;
    @SerializedName("country_name")
    private String country_name;
    @SerializedName("city")
    private String city;
    @SerializedName("street")
    private String street;
    @SerializedName("postal_code")
    private String postal_code;
    @SerializedName("address_detail")
    private String address_detail;
    @SerializedName("status")
    private String status;
    @SerializedName("state")
    private String state;
    @SerializedName("email_verified")
    private String email_verified;
    @SerializedName("phone_verified")
    private String phone_verified;
    @SerializedName("lat")
    private String lat;
    @SerializedName("lon")
    private String lon;
    @SerializedName("facebook_id")
    private String facebook_id;
    @SerializedName("google_id")
    private String google_id;
    @SerializedName("last_login_time")
    private String last_login_time;
    @SerializedName("signup_type")
    private String sign_up_type;
    @SerializedName("login_status")
    private String login_status;
    @SerializedName("add_timestamp")
    private String add_timestamp;
    @SerializedName("update_timestamp")
    private String update_timestamp;
    @SerializedName("emotion")
    private String emotion;
    @SerializedName("social_id")
    private String social_id;
    @SerializedName("prefix_mobile")
    private String prefix_mobile;
    @SerializedName("next_step")
    private String next_step;
    @SerializedName("membership_type")
    private String membership_type;
    @SerializedName("membership_time")
    private String membership_time;

    public String getMembership_type() {
        return membership_type;
    }

    public void setMembership_type(String membership_type) {
        this.membership_type = membership_type;
    }

    public String getMembership_time() {
        return membership_time;
    }


    public void setMembership_time(String membership_time) {
        this.membership_time = membership_time;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getPrefix_mobile() {
        return prefix_mobile;
    }

    public void setPrefix_mobile(String prefix_mobile) {
        this.prefix_mobile = prefix_mobile;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getNickname() {
        return nickname;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getFirst_name() {
        return first_name;
    }
    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }
    public String getLast_name() {
        return last_name;
    }
    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPhone(){ return this.phone;}
    public void setPhone(String phone){ this.phone = phone;}
    public String getCity(){ return this.city;}
    public void setCity(String city){ this.city = city;}
    public String getCountry_code() { return this.country_code;}
    public void setCountry_code(String country_code){ this.country_code = country_code;}
    public String getStreet(){ return this.street;}
    public void setStreet(String street){ this.street = street;}
    public String getPostal_code(){return this.postal_code;}
    public void setPostal_code(String postal_code){this.postal_code = postal_code;}
    public String getAddress_detail(){return this.address_detail;}
    public void setAddress_detail(String address_detail){ this.address_detail = address_detail;}

    public String getEmail_verified() {
        return email_verified;
    }

    public String getPhone_verified() {
        return phone_verified;
    }

    public void setEmail_verified(String email_verified) {
        this.email_verified = email_verified;
    }

    public void setPhone_verified(String phone_verified) {
        this.phone_verified = phone_verified;
    }

    public String getLat(){return this.lat;}
    public void setLat(String lat){this.lat = lat;}
    public String getLon(){return this.lon;}
    public void setLon(String lon){this.lon = lon;}
    public String getState() {
        return this.state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getStatus() {
        return this.status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getFacebook_id() {
        return facebook_id;
    }
    public void setFacebook_id(String facebook_id) {
        this.facebook_id = facebook_id;
    }
    public String getGoogle_id() {
        return google_id;
    }
    public void setGoogle_id(String google_id) {
        this.google_id = google_id;
    }
    public String getLast_login_time() {
        return last_login_time;
    }
    public void setLast_login_time(String last_login_time) {
        this.last_login_time = last_login_time;
    }
    public String getSign_up_type() {
        return sign_up_type;
    }
    public void setSign_up_type(String sign_up_type) {
        this.sign_up_type = sign_up_type;
    }
    public String getLogin_status() {
        return login_status;
    }
    public void setLogin_status(String login_status) {
        this.login_status = login_status;
    }
    public String getAdd_timestamp() {
        return add_timestamp;
    }
    public void setAdd_timestamp(String add_timestamp) {
        this.add_timestamp = add_timestamp;
    }
    public String getUpdate_timestamp() {
        return update_timestamp;
    }
    public void setUpdate_timestamp(String update_timestamp) {
        this.update_timestamp = update_timestamp;
    }
    public String getNext_step(){ return this.next_step;}
    public void setNext_step(String next_step) { this.next_step = next_step;}

    public String getCountry_name() {
        return country_name;
    }

    public String getEmotion() {
        return emotion;
    }

    public String getSocial_id() {
        return social_id;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public void setEmotion(String emotion) {
        this.emotion = emotion;
    }

    public void setSocial_id(String social_id) {
        this.social_id = social_id;
    }
}